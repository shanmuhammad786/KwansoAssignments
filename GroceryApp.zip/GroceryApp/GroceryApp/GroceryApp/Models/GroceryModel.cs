﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;

namespace GroceryApp.Models
{
    public class GroceryModel
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }
        public string Name { get; set; }
        public double? Amount { get; set; }
        public bool IsCompleted { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
