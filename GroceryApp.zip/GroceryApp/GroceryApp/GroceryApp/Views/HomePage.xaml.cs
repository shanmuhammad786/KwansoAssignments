﻿using GroceryApp.Models;
using GroceryApp.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace GroceryApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class HomePage : ContentPage
    {
        public HomePage()
        {
            InitializeComponent();
            BindingContext = new HomePageViewModel();
        }

        private void CheckBox_CheckedChanged(object sender, CheckedChangedEventArgs e)
        {
            var vm = BindingContext as HomePageViewModel;
            if (vm != null)
            {
                var data = sender as CheckBox;
                var index = data.BindingContext as GroceryModel;
                if (index != null)
                {
                    index.IsCompleted = e.Value;
                    var pendingList = (Application.Current as App).DbConnection.Table<PendingGroceryModel>().ToList();
                    var completedList = (Application.Current as App).DbConnection.Table<CompleteGroceryModel>().ToList();
                    if (e.Value == true)
                    {
                        var pendingGrocery = new PendingGroceryModel()
                        {
                            Name = index.Name,
                            IsCompleted = false,
                            CreatedAt = index.CreatedAt
                        };
                        var existingGrocery = pendingList.FirstOrDefault(x => x.Name == index.Name);
                        if(existingGrocery is null)
                        {
                            (Application.Current as App).DbConnection.Insert(pendingGrocery);
                        }
                    }
                    else
                    {
                        if (pendingList.Count > 0)
                        {
                            var existingGrocery = pendingList.FirstOrDefault(x => x.Name == index.Name);
                            (Application.Current as App).DbConnection.Delete(existingGrocery);
                        }
                        if (completedList.Count > 0)
                        {
                            var existingGrocery = completedList.FirstOrDefault(x => x.Name == index.Name);
                            (Application.Current as App).DbConnection.Delete(existingGrocery);
                        }

                    }
                    (Application.Current as App).DbConnection.Update(index);
                }
            }
        }
        protected override void OnAppearing()
        {
            base.OnAppearing();
            var vm = BindingContext as HomePageViewModel;
            vm.LoadGroceryList();

        }


        private void SwipeItem_Clicked(object sender, EventArgs e)
        {
            var data = sender as SwipeItem;
            var index = data.BindingContext as GroceryModel;
            if(index != null)
            {
                (Application.Current as App).DbConnection.Delete(index);
                var pendingList = (Application.Current as App).DbConnection.Table<PendingGroceryModel>().ToList();
                var completedList = (Application.Current as App).DbConnection.Table<CompleteGroceryModel>().ToList();
                if (pendingList.Count > 0)
                {
                    var existingGrocery = pendingList.FirstOrDefault(x => x.Name == index.Name);
                    (Application.Current as App).DbConnection.Delete(existingGrocery);
                }
                if (completedList.Count > 0)
                {
                    var existingGrocery = completedList.FirstOrDefault(x => x.Name == index.Name);
                    (Application.Current as App).DbConnection.Delete(existingGrocery);
                }

                var vm = BindingContext as HomePageViewModel;
                vm.LoadGroceryList();
            }
        }
    }
}