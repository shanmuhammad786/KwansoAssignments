﻿using GroceryApp.Models;
using GroceryApp.ViewModels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace GroceryApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class GroceryListPage : ContentPage
    {
        public GroceryListPage()
        {
            InitializeComponent();
            BindingContext = new GroceryListPageViewModel();
        }
        private void CheckBox_CheckedChanged(object sender, CheckedChangedEventArgs e)
        {
            var vm = BindingContext as GroceryListPageViewModel;
            if (vm != null)
            {
                var data = sender as CheckBox;
                var index = data.BindingContext as PendingGroceryModel;
                if (index != null)
                {
                    var completeList = (Application.Current as App).DbConnection.Table<CompleteGroceryModel>().ToList();
                    index.IsCompleted = e.Value;
                    if (e.Value)
                    {
                        var completeGrocery = new CompleteGroceryModel()
                        {
                            Name = index.Name,
                            IsCompleted = e.Value,
                            CreatedAt = index.CreatedAt
                        };
                        var existingGrocery = completeList.FirstOrDefault(x => x.Name == index.Name);
                        if (existingGrocery is null)
                        {
                            (Application.Current as App).DbConnection.Insert(completeGrocery);
                        }
                    }
                    else
                    {
                        if (completeList.Count > 0)
                        {
                            var existingGrocery = completeList.FirstOrDefault(x => x.Name == index.Name);
                            (Application.Current as App).DbConnection.Delete(existingGrocery);
                        }
                    }
                    (Application.Current as App).DbConnection.Update(index);
                }
            }
        }
        protected override void OnAppearing()
        {
            base.OnAppearing();
            var vm = BindingContext as GroceryListPageViewModel;
            vm.LoadList();
        }
        private void SwipeItem_Clicked(object sender, EventArgs e)
        {
            var data = sender as SwipeItem;
            var index = data.BindingContext as PendingGroceryModel;
            if (index != null)
            {
                (Application.Current as App).DbConnection.Delete(index);
                var completedList = (Application.Current as App).DbConnection.Table<CompleteGroceryModel>().ToList();
                if (completedList.Count > 0)
                {
                    var existingGrocery = completedList.FirstOrDefault(x => x.Name == index.Name);
                    (Application.Current as App).DbConnection.Delete(existingGrocery);
                }

                var vm = BindingContext as GroceryListPageViewModel;
                vm.LoadList();
            }
        }
    }
}