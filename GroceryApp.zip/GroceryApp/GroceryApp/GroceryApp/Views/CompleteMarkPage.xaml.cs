﻿using GroceryApp.Models;
using GroceryApp.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace GroceryApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CompleteMarkPage : ContentPage
    {
        public CompleteMarkPage()
        {
            InitializeComponent();
            BindingContext = new CompleteMarkPageViewModel();
        }
        private void CheckBox_CheckedChanged(object sender, CheckedChangedEventArgs e)
        {
            var vm = BindingContext as CompleteMarkPageViewModel;
            if (vm != null)
            {
                var data = sender as CheckBox;
                var index = data.BindingContext as CompleteGroceryModel;
                if (index != null)
                {
                    //(Application.Current as App).DbConnection.Delete(index);
                    var pendingGrocery = new PendingGroceryModel()
                    {
                        Name = index.Name,
                        IsCompleted = e.Value,
                        CreatedAt = index.CreatedAt
                    };
                    (Application.Current as App).DbConnection.Insert(pendingGrocery);

                    vm.LoadList();
                }
            }
        }
        protected override void OnAppearing()
        {
            base.OnAppearing();
            var vm = BindingContext as CompleteMarkPageViewModel;
            vm.LoadList();
        }
    }
}