﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace GroceryApp.Sqlite
{
    public class Database
    {
        public static string DatabasePath
        {
            get
            {
                var basePath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                return Path.Combine(basePath, "GroceryAppDB");
            }
        }
    }
}
