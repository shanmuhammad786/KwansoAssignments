﻿using GroceryApp.Models;
using GroceryApp.Sqlite;
using GroceryApp.Views;
using SQLite;
using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace GroceryApp
{
    public partial class App : Application
    {
        private SQLiteConnection _dbConnection;
        public SQLiteConnection DbConnection
        {
            get
            {
                return _dbConnection;
            }
        }

        public App()
        {
            InitializeComponent();

            //MainPage = new NavigationPage(new HomePage());
            _dbConnection = new SQLiteConnection(Database.DatabasePath);
            _dbConnection.CreateTable<GroceryModel>();
            _dbConnection.CreateTable<CompleteGroceryModel>();
            _dbConnection.CreateTable<PendingGroceryModel>();
            MainPage = new ShellPage();
        }

        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
    }
}
