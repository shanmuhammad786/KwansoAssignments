﻿using GroceryApp.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using Xamarin.Forms;

namespace GroceryApp.ViewModels
{
    public class CompleteMarkPageViewModel:BaseViewModel
    {
        #region PrivateProperties
        private ObservableCollection<CompleteGroceryModel> _groceryList;
        #endregion
        #region PublicProperties
        public ObservableCollection<CompleteGroceryModel> GroceryList
        {
            get
            {
                return _groceryList;
            }
            set
            {
                _groceryList = value;
                OnPropertyChanged();
            }
        }
        #endregion
        public CompleteMarkPageViewModel()
        {
            GroceryList = new ObservableCollection<CompleteGroceryModel>();
            LoadList();
        }
        #region Methods
        public void LoadList()
        {
            var groceryList = (Application.Current as App).DbConnection.Table<CompleteGroceryModel>().ToList();
            GroceryList = new ObservableCollection<CompleteGroceryModel>(groceryList.OrderByDescending(x => x.CreatedAt).ToList());
        }
        #endregion
    }
}
