﻿using GroceryApp.Models;
using GroceryApp.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace GroceryApp.ViewModels
{
    public class GroceryListPageViewModel:BaseViewModel
    {
        #region PrivateProperties
        private ObservableCollection<PendingGroceryModel> _groceryList;
        #endregion
        #region PublicProperties
        public ObservableCollection<PendingGroceryModel> GroceryList
        {
            get
            {
                return _groceryList;
            }
            set
            {
                _groceryList = value;
                OnPropertyChanged();
            }
        }
        #endregion
        public GroceryListPageViewModel()
        {
            GroceryList = new ObservableCollection<PendingGroceryModel>();
        }
        #region Commands
        public ICommand CompletedMarkCommand => new Command(CompletedGroceries);
        #endregion
        #region Methods
        private void CompletedGroceries()
        {
            Application.Current.MainPage.Navigation.PushAsync(new CompleteMarkPage());
        }
        public void LoadList()
        {
            var groceryList = (Application.Current as App).DbConnection.Table<PendingGroceryModel>().ToList();
            GroceryList = new ObservableCollection<PendingGroceryModel>(groceryList.OrderByDescending(x => x.CreatedAt).ToList());
        }
        #endregion
    }
}
