﻿using GroceryApp.Models;
using GroceryApp.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.Design.Serialization;
using System.Linq;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace GroceryApp.ViewModels
{
    public class HomePageViewModel : BaseViewModel
    {
        #region PrivateProperties
        private ObservableCollection<GroceryModel> _groceryList;
        private string _groceryName;
        private double? _amount;
        #endregion
        #region PublicProperties
        public string GroceryName
        {
            get
            {
                return _groceryName;
            }
            set
            {
                _groceryName = value;
                OnPropertyChanged();
            }
        }
        public double? Amount
        {
            get
            {
                return _amount;
            }
            set
            {
                _amount = value;
                OnPropertyChanged();
            }
        }
        public ObservableCollection<GroceryModel> GroceryList
        {
            get
            {
                return _groceryList;
            }
            set
            {
                _groceryList = value;
                OnPropertyChanged();
            }
        }
        #endregion
        public HomePageViewModel()
        {
            GroceryList = new ObservableCollection<GroceryModel>();
        }
        #region Commands
        public ICommand AddGroceryCommand => new Command(AddGrocery);
        public ICommand InsertGroceryCommand => new Command(InsertGrocery);
        #endregion

        #region Methods
        private void AddGrocery()
        {
            Application.Current.MainPage.Navigation.PushAsync(new CreateGroceryPage() { BindingContext = this });

        }
        private void InsertGrocery()
        {
            if (!string.IsNullOrEmpty(GroceryName))
            {
                if(Amount is null)
                {
                    Amount = 0.0;
                }
                var groceryList = (Application.Current as App).DbConnection.Table<GroceryModel>().ToList();
                if (groceryList.Count > 0)
                {
                    var existingGrocery = groceryList.FirstOrDefault(x => x.Name == GroceryName);
                    if (existingGrocery != null)
                    {
                        Application.Current.MainPage.DisplayAlert("Alert", $"{GroceryName} is already exist. Please try a different name", "OK");
                    }
                    else
                    {
                        (Application.Current as App).DbConnection.Insert(new GroceryModel() { Name = GroceryName, IsCompleted = false, CreatedAt = DateTime.Now, Amount = Amount });
                        LoadGroceryList();
                        Application.Current.MainPage.Navigation.PopAsync();
                    }
                }
                else
                {
                    (Application.Current as App).DbConnection.Insert(new GroceryModel() { Name = GroceryName, IsCompleted = false, CreatedAt = DateTime.Now });
                    LoadGroceryList();
                    Application.Current.MainPage.Navigation.PopAsync();
                }

            }

        }
        public void LoadGroceryList()
        {
            var groceryList = (Application.Current as App).DbConnection.Table<GroceryModel>().ToList();
            GroceryList = new ObservableCollection<GroceryModel>(groceryList.OrderByDescending(x => x.CreatedAt).ToList());
        }
        #endregion

    }
}
