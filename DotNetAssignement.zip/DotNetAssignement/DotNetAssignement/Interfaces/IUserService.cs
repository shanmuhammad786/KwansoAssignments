﻿using DotNetAssignement.DomainModels;
using DotNetAssignement.Specifications.Filters;
using DotNetAssignement.ViewModels;

namespace DotNetAssignement.Interfaces
{
    public interface IUserService
    {
        Task<string> Login(User user);
        Task<User> Register(User user);
        Task<UserResVM> GetUser(int id);
        Task<DomainModels.Task> CreateTask(DomainModels.Task task);
        Task<GetAllTasksResVM> GetAllTasks(TasksFilter tasksFilter);
    }
}
