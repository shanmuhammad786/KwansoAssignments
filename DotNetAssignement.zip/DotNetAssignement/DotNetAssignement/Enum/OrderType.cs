﻿namespace DotNetAssignement.Enum
{
    public enum OrderType
    {
        Asc = 1,
        Desc = 2
    }
}
