﻿using DotNetAssignement.Enum;
using System.Linq.Expressions;

namespace DotNetAssignement.Extenions
{
    public static class LinqGenericSortExtension
    {
        public static IQueryable<TSource> ApplySort<TSource>(this IQueryable<TSource> source, string sortBy, int sortDirection)
        {
            var param = Expression.Parameter(typeof(TSource), "item");

            var sortExpression = Expression.Lambda<Func<TSource, object>>
                (Expression.Convert(Expression.Property(param, sortBy), typeof(object)), param);

            return sortDirection switch
            {
                (int)OrderType.Desc =>
                     source.AsQueryable().OrderByDescending(sortExpression),
                _ =>
                     source.AsQueryable().OrderBy(sortExpression),
            };

        }
    }
}
