﻿namespace DotNetAssignement.ViewModels
{
    public class TaskResVM
    {
        public int Id { get; set; }
        public string TaskName { get; set; }
    }
}
