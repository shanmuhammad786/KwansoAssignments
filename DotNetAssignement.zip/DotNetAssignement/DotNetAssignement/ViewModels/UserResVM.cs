﻿namespace DotNetAssignement.ViewModels
{
    public class UserResVM
    {
        public int Id { get; set;}
        public string Email { get; set;}
    }
}
