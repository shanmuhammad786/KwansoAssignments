﻿namespace DotNetAssignement.ViewModels
{
    public class TaskReqVM
    {
        public string Name { get; set; }
    }
}
