﻿namespace DotNetAssignement.ViewModels
{
    public class GetAllTasksResVM
    {
        public int TotalCount { get; set; }
        public IList<TaskResVM> Tasks { get; set; }
    }
}
