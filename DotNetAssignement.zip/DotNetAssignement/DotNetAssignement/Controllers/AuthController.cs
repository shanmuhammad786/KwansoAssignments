﻿using DotNetAssignement.DomainModels;
using DotNetAssignement.Interfaces;
using DotNetAssignement.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace DotNetAssignement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController: ControllerBase
    {
        private readonly IUserService _userService;
        public AuthController(IUserService userService)
        {
            _userService = userService;
        }
        [HttpPost]
        [Route("login")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]

        public async Task<IActionResult> Login([FromBody] UserReqVM userReqVM)
        {
            var userReq = new User()
            {
                Email = userReqVM.Email,
                Password = userReqVM.Password,
            };
            return Ok(new { jwt = await _userService.Login(userReq) });
        }
        [HttpPost]
        [Route("register")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        public async Task<IActionResult> Register([FromBody] UserReqVM userReqVM)
        {
            var userReq = new User()
            {
                Email = userReqVM.Email,
                Password = userReqVM.Password,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,
            };
            return Ok(await _userService.Register(userReq));
        }
    }
}
