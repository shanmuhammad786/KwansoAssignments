﻿using DotNetAssignement.DomainModels;
using DotNetAssignement.Interfaces;
using DotNetAssignement.Specifications.Filters;
using DotNetAssignement.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace DotNetAssignement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class UserController: ControllerBase
    {
        private readonly IUserService _userService;
        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpGet]
        [Route("user/{id}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        public async Task<IActionResult> GetUser([FromRoute] int id)
        {
            
            return Ok(await _userService.GetUser(id));
        }
        [HttpPost]
        [Route("create-task")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        public async Task<IActionResult> CreateTask([FromBody] TaskReqVM taskReqVM)
        {
            var task = new DomainModels.Task()
            {
                Name = taskReqVM.Name,
            };
            return Ok(await _userService.CreateTask(task));
        }
        [HttpGet]
        [Route("list-tasks")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        public async Task<IActionResult> GetAllTasks([FromQuery] TasksFilter tasksFilter)
        {
            return Ok(await _userService.GetAllTasks(tasksFilter));
        }
    }
}
