﻿using DotNetAssignement.Enum;

namespace DotNetAssignement.Specifications.Filters
{
    public class BaseFilter
    {
        public int Page { get; set; }
        public int PageSize { get; set; }

        public string? OrderBy { get; set; }
        public OrderType? OrderType { get; set; }


        public static int DefaultPage => 1;
        public static int DefaultPageSize => 10;

        public int DefaultOrderType => 2;
        public string DefaultOrderBy => "Id";

        public int CalculateTake()
        {
            return PageSize <= 0 ? DefaultPageSize : PageSize;

        }
        public int CalculateSkip()
        {
            Page = Page <= 0 ? DefaultPage : Page;
            PageSize = PageSize <= 0 ? DefaultPageSize : PageSize;
            return (PageSize) * (Page - 1);
        }
    }
}
