﻿namespace DotNetAssignement.Specifications.Filters
{
    public class TasksFilter:BaseFilter
    {
        public string? TaskName { get; set; }
    }
}
