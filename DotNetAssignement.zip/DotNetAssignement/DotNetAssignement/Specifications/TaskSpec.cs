﻿using DotNetAssignement.Extenions;
using DotNetAssignement.Specifications.Filters;
using DotNetAssignement.ViewModels;

namespace DotNetAssignement.Specifications
{
    public static class TaskSpec
    {
        public static IQueryable<TaskResVM> ApplyTaskFilterSpec(this IQueryable<TaskResVM> query, TasksFilter taskFilter)
        {
            if (!string.IsNullOrEmpty(taskFilter.TaskName))
                query = query.Where(x => x.TaskName.Contains(taskFilter.TaskName));

            return query;
        }
        public static IQueryable<TaskResVM> ApplyTaskPaginationSpec(this IQueryable<TaskResVM> query, TasksFilter taskFilter)
        {
            var orderType = taskFilter.DefaultOrderType;
            if (taskFilter.OrderType != null)
                orderType = (int)taskFilter.OrderType;

            var OrderBy = taskFilter.DefaultOrderBy;
            if (taskFilter.OrderBy != null)
            {
                OrderBy = taskFilter.OrderBy;
            }
            query = query.ApplySort(OrderBy, orderType);

            return query.Skip(taskFilter.CalculateSkip()).Take(taskFilter.CalculateTake());
        }
    }
}
