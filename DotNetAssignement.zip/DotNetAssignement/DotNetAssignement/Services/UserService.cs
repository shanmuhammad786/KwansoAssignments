﻿using DotNetAssignement.Configuration;
using DotNetAssignement.DomainModels;
using DotNetAssignement.Interfaces;
using DotNetAssignement.Specifications;
using DotNetAssignement.Specifications.Filters;
using DotNetAssignement.ViewModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace DotNetAssignement.Services
{
    public class UserService : IUserService
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly JwtBearerTokenSettings jwtBearerTokenSettings;

        public UserService(ApplicationDbContext dbContext, IOptions<JwtBearerTokenSettings> jwtTokenOptions)
        {
            _dbContext = dbContext;
            this.jwtBearerTokenSettings = jwtTokenOptions.Value;
        }
        public async Task<string> Login(User user)
        {
            var userFound = _dbContext.Users
                .FirstOrDefault(x => x.Email == user.Email && x.Password == user.Password);
            if (userFound == null)
            {
                throw new UnauthorizedAccessException("Email or Password is incorrect");
            }

            return await GenerateAccessTokenAsync(userFound);
        }
        public async Task<User> Register(User user)
        {
            try
            {
                await _dbContext.Users.AddAsync(user);
                await _dbContext.SaveChangesAsync();
                return user;
            }
            catch (Exception)
            {
                throw new Exception("There is an error in User Creation");
            }
        }
        private async Task<string> GenerateAccessTokenAsync(User user)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(jwtBearerTokenSettings.SecretKey);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new System.Security.Claims.Claim[]
                {
                    new System.Security.Claims.Claim("UserId", user.Id.ToString()),
                    new System.Security.Claims.Claim(ClaimTypes.Name, user.Email.ToString()),
                }),
                Expires = DateTime.Now.AddSeconds(jwtBearerTokenSettings.ExpiryTimeInSeconds),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
                Audience = jwtBearerTokenSettings.Audience,
                Issuer = jwtBearerTokenSettings.Issuer

            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
        public async Task<UserResVM> GetUser(int id)
        {
            var user = _dbContext.Users.
                FirstOrDefault(x => x.Id == id);
            if (user == null)
            {
                throw new KeyNotFoundException("User not found");
            }
            var userResVM = new UserResVM()
            {
                Email = user.Email,
                Id = user.Id
            };
            return userResVM;
        }

        public async Task<DomainModels.Task> CreateTask(DomainModels.Task task)
        {
            try
            {
                await _dbContext.Tasks.AddAsync(task);
                await _dbContext.SaveChangesAsync();
                return task;
            }
            catch (Exception)
            {
                throw new Exception("There is an error in Task Creation");
            }
        }

        public async Task<GetAllTasksResVM> GetAllTasks(TasksFilter tasksFilter)
        {
            try
            {
                var filterQuery = _dbContext.Tasks
                    .Select(x => new TaskResVM()
                    {
                        Id = x.Id,
                        TaskName = x.Name
                    }).ApplyTaskFilterSpec(tasksFilter);

                var getAllTasksResVM = new GetAllTasksResVM()
                {
                    TotalCount = filterQuery.Count()
                };
                filterQuery = filterQuery.ApplyTaskPaginationSpec(tasksFilter);
                var tasks = await filterQuery.ToListAsync();

                getAllTasksResVM.Tasks = tasks;
                return getAllTasksResVM;
            }
            catch (Exception)
            {
                throw new Exception("There is an error in Task Creation");
            }
        }
    }
}
